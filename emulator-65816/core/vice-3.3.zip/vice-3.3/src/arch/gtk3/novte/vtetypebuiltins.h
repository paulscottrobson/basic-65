
/* Generated data (by glib-mkenums) */


#ifndef __VTE_NOVTE_TYPE_BUILTINS_H__
#define __VTE_NOVTE_TYPE_BUILTINS_H__

#include <glib-object.h>

#include "vtemacros.h"

G_BEGIN_DECLS

/* enumerations from "vteenums.h" */
_VTE_PUBLIC
GType vte_cursor_blink_mode_get_type (void);
#define VTE_TYPE_CURSOR_BLINK_MODE (vte_cursor_blink_mode_get_type ())
_VTE_PUBLIC
GType vte_cursor_shape_get_type (void);
#define VTE_TYPE_CURSOR_SHAPE (vte_cursor_shape_get_type ())
_VTE_PUBLIC
GType vte_text_blink_mode_get_type (void);
#define VTE_TYPE_TEXT_BLINK_MODE (vte_text_blink_mode_get_type ())
_VTE_PUBLIC
GType vte_erase_binding_get_type (void);
#define VTE_TYPE_ERASE_BINDING (vte_erase_binding_get_type ())
_VTE_PUBLIC
GType vte_write_flags_get_type (void);
#define VTE_TYPE_WRITE_FLAGS (vte_write_flags_get_type ())
_VTE_PUBLIC
GType vte_format_get_type (void);
#define VTE_TYPE_FORMAT (vte_format_get_type ())
G_END_DECLS

#endif /* __VTE_NOVTE_TYPE_BUILTINS_H__ */

/* Generated data ends here */

